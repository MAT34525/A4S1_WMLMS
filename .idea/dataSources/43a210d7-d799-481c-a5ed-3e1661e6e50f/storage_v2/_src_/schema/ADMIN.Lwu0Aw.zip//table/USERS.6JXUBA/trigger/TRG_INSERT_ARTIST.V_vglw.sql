create trigger TRG_INSERT_ARTIST
    after update of IS_ARTIST
    on USERS
    for each row
BEGIN
    IF :NEW.is_artist = 'Y' AND :OLD.is_artist = 'N' THEN
        INSERT INTO artists (artist_id, name, followers, genres, popularity, created_at, updated_at)
        VALUES (generate_uuid(), :NEW.full_name, 0, NULL, 0, SYSDATE, SYSDATE);
    END IF;
END;
/

