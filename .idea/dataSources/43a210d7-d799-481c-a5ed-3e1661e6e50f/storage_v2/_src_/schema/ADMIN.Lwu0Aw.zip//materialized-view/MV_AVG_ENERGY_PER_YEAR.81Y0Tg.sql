create materialized view MV_AVG_ENERGY_PER_YEAR
    refresh force on demand
as
SELECT EXTRACT(YEAR FROM t.release_date) AS release_year, AVG(taf.energy) AS avg_energy
FROM tracks t
JOIN tracks_audio_features taf ON t.track_id = taf.track_id
GROUP BY EXTRACT(YEAR FROM t.release_date)
/

