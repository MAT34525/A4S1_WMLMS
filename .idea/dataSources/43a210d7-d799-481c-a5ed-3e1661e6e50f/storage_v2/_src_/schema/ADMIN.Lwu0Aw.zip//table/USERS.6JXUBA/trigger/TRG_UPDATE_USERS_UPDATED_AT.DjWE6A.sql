create trigger TRG_UPDATE_USERS_UPDATED_AT
    before update
    on USERS
    for each row
BEGIN
    :NEW.updated_at := SYSDATE;
    add_log(:NEW.user_id, 'USER_UPDATED', 'User updated: ' || :NEW.username, NULL);
END;
/

