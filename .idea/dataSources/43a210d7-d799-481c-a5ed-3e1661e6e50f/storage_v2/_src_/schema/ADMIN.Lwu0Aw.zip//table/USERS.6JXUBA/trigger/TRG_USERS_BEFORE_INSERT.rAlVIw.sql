create trigger TRG_USERS_BEFORE_INSERT
    before insert
    on USERS
    for each row
BEGIN
    IF :NEW.user_id IS NULL THEN
        :NEW.user_id := generate_uuid();
    END IF;
    :NEW.salt := DBMS_RANDOM.STRING('X', 64);
    :NEW.password := hash_password(:NEW.password, :NEW.salt);
END;
/

