create trigger TRG_UPDATE_ARTISTS_UPDATED_AT
    before update
    on ARTISTS
    for each row
BEGIN
    :NEW.updated_at := SYSDATE;
END;
/

