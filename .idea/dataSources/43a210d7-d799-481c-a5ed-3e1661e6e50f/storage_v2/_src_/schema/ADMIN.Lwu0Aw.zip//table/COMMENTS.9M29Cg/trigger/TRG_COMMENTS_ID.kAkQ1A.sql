create trigger TRG_COMMENTS_ID
    before insert
    on COMMENTS
    for each row
BEGIN
    IF :NEW.comment_id IS NULL THEN
        :NEW.comment_id := generate_uuid(); 
    END IF;
END;
/

