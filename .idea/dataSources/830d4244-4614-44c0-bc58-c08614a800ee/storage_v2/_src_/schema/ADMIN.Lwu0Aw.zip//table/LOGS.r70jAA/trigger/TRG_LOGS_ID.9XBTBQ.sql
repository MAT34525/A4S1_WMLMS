create trigger TRG_LOGS_ID
    before insert
    on LOGS
    for each row
BEGIN
    IF :NEW.log_id IS NULL THEN
        :NEW.log_id := generate_uuid();
    END IF;
END;
/

