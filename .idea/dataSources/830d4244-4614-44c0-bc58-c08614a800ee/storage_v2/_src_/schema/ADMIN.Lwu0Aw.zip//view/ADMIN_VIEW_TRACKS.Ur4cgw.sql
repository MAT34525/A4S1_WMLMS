create view ADMIN_VIEW_TRACKS as
SELECT t.track_id, t.name, t.artists, t.duration_ms, t.explicit, t.release_date, t.id_artists
FROM tracks t
/

