create trigger TRG_ARTISTS_ID
    before insert
    on ARTISTS
    for each row
BEGIN
    IF :NEW.artist_id IS NULL THEN
        :NEW.artist_id := generate_uuid();
    END IF;
END;
/

