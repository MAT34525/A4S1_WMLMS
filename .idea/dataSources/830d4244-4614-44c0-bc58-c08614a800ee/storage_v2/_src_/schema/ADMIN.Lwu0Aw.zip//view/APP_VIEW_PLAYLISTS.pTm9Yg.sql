create view APP_VIEW_PLAYLISTS as
SELECT p.playlist_id, p.name, p.is_public, p.created_at AS creation_date, u.username AS user_name
FROM playlists p
JOIN users u ON p.user_id = u.user_id
/

