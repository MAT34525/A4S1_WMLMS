create trigger TRG_USERS_BEFORE_UPDATE
    before update of PASSWORD
    on USERS
    for each row
BEGIN
    :NEW.salt := DBMS_RANDOM.STRING('X', 64);
    --:NEW.password := hash_password(:NEW.password, :NEW.salt);
END;
/

