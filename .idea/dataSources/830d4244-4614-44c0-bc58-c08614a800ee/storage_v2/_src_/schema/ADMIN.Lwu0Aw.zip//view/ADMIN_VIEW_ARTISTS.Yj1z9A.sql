create view ADMIN_VIEW_ARTISTS as
SELECT artist_id, name, followers, genres, popularity
FROM artists
/

