create FUNCTION generate_monthly_report RETURN VARCHAR2 IS
    v_report VARCHAR2(4000);
BEGIN
    SELECT "Nombre d utilisateurs ajoutés ce mois-ci : " || COUNT(*)
    INTO v_report
    FROM users
    WHERE EXTRACT(MONTH FROM created_at) = EXTRACT(MONTH FROM SYSDATE)
      AND EXTRACT(YEAR FROM created_at) = EXTRACT(YEAR FROM SYSDATE);

    RETURN v_report;
END;
/

