create FUNCTION get_playlist_duration(p_playlist_id VARCHAR2)
RETURN NUMBER
IS
  v_total_duration NUMBER;
BEGIN
  SELECT SUM(t.duration_ms)
  INTO v_total_duration
  FROM tracks t
  JOIN playlist_tracks pt ON t.track_id = pt.track_id
  WHERE pt.playlist_id = p_playlist_id;

  RETURN NVL(v_total_duration, 0); -- renvoie 0 si aucune piste n'est trouvée
END;
/

