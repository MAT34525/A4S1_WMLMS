create PROCEDURE send_alert(p_message VARCHAR2) IS
BEGIN
    INSERT INTO alert_log (message, created_at) VALUES (p_message, SYSDATE);
END;
/

