create trigger TRG_UPDATE_TRACKS_UPDATED_AT
    before update
    on TRACKS
    for each row
BEGIN
    :NEW.updated_at := SYSDATE;
END;
/

