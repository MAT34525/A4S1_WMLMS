create view APP_VIEW_TRACKS as
SELECT t.track_id, t.name, t.artists, t.duration_ms, t.release_date
FROM tracks t
/

