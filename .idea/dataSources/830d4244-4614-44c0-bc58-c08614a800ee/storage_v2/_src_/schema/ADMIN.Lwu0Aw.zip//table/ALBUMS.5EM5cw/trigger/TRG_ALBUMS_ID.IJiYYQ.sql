create trigger TRG_ALBUMS_ID
    before insert
    on ALBUMS
    for each row
BEGIN
    IF :NEW.album_id IS NULL THEN
        :NEW.album_id := generate_uuid();
    END IF;
END;
/

