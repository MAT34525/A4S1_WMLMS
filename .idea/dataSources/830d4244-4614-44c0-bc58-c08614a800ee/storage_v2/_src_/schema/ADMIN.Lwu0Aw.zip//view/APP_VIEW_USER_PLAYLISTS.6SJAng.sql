create view APP_VIEW_USER_PLAYLISTS as
SELECT p.playlist_id, p.name, p.is_public, p.created_at AS creation_date, 
       u.username AS user_name, t.name AS track_name
FROM playlists p
JOIN users u ON p.user_id = u.user_id
JOIN user_favorite_tracks uft ON p.user_id = uft.user_id
JOIN tracks t ON uft.track_id = t.track_id
/

