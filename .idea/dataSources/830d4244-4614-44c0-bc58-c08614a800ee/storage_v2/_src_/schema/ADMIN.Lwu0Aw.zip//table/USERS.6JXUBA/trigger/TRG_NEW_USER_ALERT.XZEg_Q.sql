create trigger TRG_NEW_USER_ALERT
    after insert
    on USERS
    for each row
BEGIN
    send_alert('Nouvel utilisateur ajouté : ' || :NEW.username); -- appel d'une procédure pour envoyer une alerte
END;
/

