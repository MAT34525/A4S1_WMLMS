create FUNCTION custom_hash(p_input VARCHAR2)
RETURN VARCHAR2
IS
    v_hash NUMBER := 0;
BEGIN
    FOR i IN 1..LENGTH(p_input) LOOP
        v_hash := MOD(v_hash * 31 + ASCII(SUBSTR(p_input, i, 1)), 1000000007);
    END LOOP;
    RETURN TO_CHAR(v_hash, 'FM0000000000');
END;
/

