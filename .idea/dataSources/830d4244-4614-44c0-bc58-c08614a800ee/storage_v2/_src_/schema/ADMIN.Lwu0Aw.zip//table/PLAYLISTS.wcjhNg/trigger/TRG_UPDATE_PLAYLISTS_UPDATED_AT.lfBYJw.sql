create trigger TRG_UPDATE_PLAYLISTS_UPDATED_AT
    before update
    on PLAYLISTS
    for each row
BEGIN
    :NEW.updated_at := SYSDATE;
END;
/

