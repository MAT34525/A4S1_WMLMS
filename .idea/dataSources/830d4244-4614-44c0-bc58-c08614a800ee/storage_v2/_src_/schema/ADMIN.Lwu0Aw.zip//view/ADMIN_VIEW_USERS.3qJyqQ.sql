create view ADMIN_VIEW_USERS as
SELECT user_id, username, full_name, email, is_artist, created_at, updated_at
FROM users
/

