create trigger TRG_PREVENT_FAVORITE_PLAYLIST_DELETE
    before delete
    on PLAYLISTS
    for each row
BEGIN
    IF :OLD.is_favorite = 'Y' THEN
        RAISE_APPLICATION_ERROR(-20001, 'Cannot delete favorite playlist');
    END IF;
END;
/

