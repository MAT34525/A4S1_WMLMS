create FUNCTION hash_password(p_password VARCHAR2, p_salt VARCHAR2)
RETURN VARCHAR2
IS
BEGIN
    RETURN custom_hash(p_password || p_salt);
END;
/

