create PROCEDURE add_log(
    p_user_id VARCHAR2,
    p_event_type VARCHAR2,
    p_event_description VARCHAR2,
    p_ip_address VARCHAR2
)
IS
BEGIN
    INSERT INTO logs (user_id, event_type, event_description, ip_address)
    VALUES (p_user_id, p_event_type, p_event_description, p_ip_address);
END;
/

