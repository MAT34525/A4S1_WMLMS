create trigger TRG_FORUM_POSTS_ID
    before insert
    on FORUM_POSTS
    for each row
BEGIN
    IF :NEW.post_id IS NULL THEN
        :NEW.post_id := generate_uuid();
    END IF;
END;
/

