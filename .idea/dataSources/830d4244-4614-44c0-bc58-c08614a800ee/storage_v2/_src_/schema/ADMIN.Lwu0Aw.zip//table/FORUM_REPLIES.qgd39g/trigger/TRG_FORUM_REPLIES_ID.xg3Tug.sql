create trigger TRG_FORUM_REPLIES_ID
    before insert
    on FORUM_REPLIES
    for each row
BEGIN
    IF :NEW.reply_id IS NULL THEN
        :NEW.reply_id := generate_uuid();
    END IF;
END;
/

