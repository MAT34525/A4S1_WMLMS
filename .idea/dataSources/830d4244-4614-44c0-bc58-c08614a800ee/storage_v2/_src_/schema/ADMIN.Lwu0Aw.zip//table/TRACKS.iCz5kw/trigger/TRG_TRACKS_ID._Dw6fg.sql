create trigger TRG_TRACKS_ID
    before insert
    on TRACKS
    for each row
BEGIN
    IF :NEW.track_id IS NULL THEN
        :NEW.track_id := generate_uuid();
    END IF;
END;
/

