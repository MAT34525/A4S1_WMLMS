create trigger TRG_PLAYLISTS_ID
    before insert
    on PLAYLISTS
    for each row
BEGIN
    IF :NEW.playlist_id IS NULL THEN
        :NEW.playlist_id := generate_uuid();
    END IF;
END;
/

